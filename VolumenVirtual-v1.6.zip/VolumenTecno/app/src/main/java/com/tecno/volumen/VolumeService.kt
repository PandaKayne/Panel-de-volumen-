package com.tecno.volumen

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.roundToInt

/** Barra vertical táctil (estilo Samsung/Xiaomi). */
class VBar(c: Context, private val track: Int, fillColor: Int) : View(c) {
    var fill = fillColor
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    var frac = 0f
        set(v) { field = v; invalidate() }
    var onChange: ((Float) -> Unit)? = null

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val r = w / 2
        path.reset(); path.addRoundRect(0f, 0f, w, h, r, r, Path.Direction.CW)
        p.color = track; c.drawPath(path, p)
        c.save(); c.clipPath(path)
        p.color = fill; c.drawRect(0f, h * (1 - frac), w, h, p)
        c.restore()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (height > 0 && (e.action == MotionEvent.ACTION_DOWN || e.action == MotionEvent.ACTION_MOVE)) {
            onChange?.invoke(1f - (e.y / height).coerceIn(0f, 1f))
        }
        return true
    }
}

class VolumeService : AccessibilityService() {
    private val am by lazy { getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    private val wm by lazy { getSystemService(Context.WINDOW_SERVICE) as WindowManager }
    private val h = Handler(Looper.getMainLooper())
    private val hideR = Runnable { safe("ocultar panel") { removePanel(); expanded = false } }
    private var panel: View? = null
    private var builtFor = -1
    private var expanded = false
    private var auto = -1
    private var fg = ""
    private val cols = ArrayList<Triple<Int, VBar, TextView>>()

    /** Ejecuta algo sin dejar que un error tumbe el servicio; lo guarda en el diagnóstico. */
    private inline fun safe(where: String, block: () -> Unit) {
        try {
            block()
        } catch (t: Throwable) {
            try { Prefs.logError(this, where, t) } catch (_: Throwable) {}
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        stopRepeat()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        safe("evento de ventana") {
            if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
            val pkg = e.packageName?.toString() ?: return
            if (pkg == "com.android.systemui" || pkg == packageName ||
                pkg.contains("inputmethod") || pkg.contains("keyboard")
            ) return
            fg = pkg
            auto = Prefs.profileForApp(this, pkg)
        }
    }

    override fun onInterrupt() { stopRepeat() }

    // Repetición al mantener pulsado: el servicio no recibe los repetidos del sistema, así que se hace aquí.
    private var repeating = false
    private var repeatUp = false
    private var repeatTicks = 0
    private val repeatR = object : Runnable {
        override fun run() {
            safe("repetir volumen") {
                if (!repeating || ++repeatTicks > 150) { stopRepeat(); return }
                step(repeatUp)
                h.postDelayed(this, 80)
            }
        }
    }

    private fun stopRepeat() {
        repeating = false
        repeatTicks = 0
        h.removeCallbacks(repeatR)
    }

    override fun onKeyEvent(e: KeyEvent): Boolean {
        return try {
            handleKey(e)
        } catch (t: Throwable) {
            stopRepeat()
            try { Prefs.logError(this, "botón de volumen", t) } catch (_: Throwable) {}
            false   // si algo falla, el sistema maneja el volumen como siempre
        }
    }

    private fun handleKey(e: KeyEvent): Boolean {
        if (e.keyCode != KeyEvent.KEYCODE_VOLUME_UP && e.keyCode != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        if (!Prefs.enabled(this)) return false
        if (fg.contains("camera", true) || fg.contains("snapcam", true) || fg in Prefs.excluded(this)) {
            stopRepeat()
            return false   // la cámara usa el botón de volumen como disparador
        }
        val up = e.keyCode == KeyEvent.KEYCODE_VOLUME_UP
        when (e.action) {
            KeyEvent.ACTION_DOWN -> if (e.repeatCount == 0) {
                stopRepeat()
                step(up)
                repeatUp = up
                repeating = true
                h.postDelayed(repeatR, 400)
            }
            KeyEvent.ACTION_UP -> stopRepeat()
        }
        return true
    }

    private fun prof() = if (auto >= 0) auto else Prefs.active(this)

    private fun streamNow(): Int = when (am.mode) {
        AudioManager.MODE_IN_CALL, AudioManager.MODE_IN_COMMUNICATION -> AudioManager.STREAM_VOICE_CALL
        AudioManager.MODE_RINGTONE -> AudioManager.STREAM_RING
        else -> Prefs.STREAMS[Prefs.stream(this, prof())]
    }

    private fun isRinger(s: Int) = s == AudioManager.STREAM_RING || s == AudioManager.STREAM_NOTIFICATION

    /** Volumen real: en vibración/silencio el timbre cuenta como 0. */
    private fun curVol(s: Int) =
        if (isRinger(s) && am.ringerMode != AudioManager.RINGER_MODE_NORMAL) 0 else am.getStreamVolume(s)

    private fun step(up: Boolean) {
        val s = streamNow()
        val max = am.getStreamMaxVolume(s)
        if (max <= 0) return
        val v = (curVol(s) + if (up) 1 else -1).coerceIn(0, max)
        setVol(s, v)
        show(s)
    }

    private fun setVol(s: Int, v: Int) {
        if (isRinger(s)) {
            try {
                if (v <= 0) { am.ringerMode = AudioManager.RINGER_MODE_VIBRATE; return }   // 0 = vibración
                if (am.ringerMode != AudioManager.RINGER_MODE_NORMAL) am.ringerMode = AudioManager.RINGER_MODE_NORMAL
            } catch (_: SecurityException) {}
        }
        try {
            am.setStreamVolume(s, v, 0)
        } catch (e: SecurityException) {
            // Timbre/notificación a 0 puede requerir acceso a "No molestar"
            try { am.setStreamVolume(s, v.coerceAtLeast(1), 0) } catch (_: Exception) {}
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()

    private fun show(active: Int) {
        if (panel == null || (!expanded && builtFor != active)) { removePanel(); build(active) }
        refresh()
        resetTimer()
    }

    private fun resetTimer() {
        h.removeCallbacks(hideR)
        h.postDelayed(hideR, Prefs.timeout(this, prof()) * 1000L + if (expanded) 2000 else 0)
    }

    private fun removePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    private fun refresh() {
        for ((s, bar, t) in cols) {
            val max = am.getStreamMaxVolume(s)
            if (max <= 0) continue
            val v = curVol(s)
            bar.frac = v / max.toFloat()
            t.text = (v * 100f / max).roundToInt().toString()
        }
    }

    private fun build(active: Int) {
        val k = Prefs.scale(this) / 100f
        fun d(v: Int) = dp((v * k).roundToInt())
        val samsung = Prefs.style(this) != 1
        val fillC = Prefs.fill(this)
        val bg = GradientDrawable().apply {
            setColor(Prefs.bg(this@VolumeService))
            cornerRadius = d(if (samsung) 26 else 34).toFloat()
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = bg
            setPadding(d(14), d(14), d(14), d(6))
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        cols.clear()
        val idx = if (expanded) Prefs.STREAMS.indices.toList()
        else listOf(Prefs.STREAMS.indexOf(active).coerceAtLeast(0))
        for (i in idx) {
            val s = Prefs.STREAMS[i]
            val pct = TextView(this).apply { setTextColor(-1); textSize = 12f * k; gravity = Gravity.CENTER }
            val bar = VBar(this, 0x33FFFFFF, fillC)
            bar.onChange = { f ->
                safe("barra del panel") {
                    val max = am.getStreamMaxVolume(s)
                    if (max > 0) setVol(s, (f * max).roundToInt())
                    refresh(); resetTimer()
                }
            }
            val icon = TextView(this).apply {
                text = Prefs.ICONS[i]; textSize = 18f * k; gravity = Gravity.CENTER
                setPadding(0, d(6), 0, 0)
            }
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(d(6), 0, d(6), 0)
                addView(pct, LinearLayout.LayoutParams(d(44), LinearLayout.LayoutParams.WRAP_CONTENT))
                addView(bar, LinearLayout.LayoutParams(d(if (samsung) 42 else 32), d(170)).apply { topMargin = d(6) })
                addView(icon)
            }
            row.addView(col)
            cols.add(Triple(s, bar, pct))
        }
        val more = TextView(this).apply {
            text = if (expanded) "▴" else "⋯"
            setTextColor(0xCCFFFFFF.toInt()); textSize = 20f * k; gravity = Gravity.CENTER
            setPadding(d(20), d(2), d(20), d(4))
            setOnClickListener { safe("ampliar panel") { expanded = !expanded; removePanel(); build(active); refresh(); resetTimer() } }
        }
        root.addView(row); root.addView(more)

        val outside = Prefs.closeOutside(this)
        if (outside) {
            // Un toque fuera del panel lo cierra (el toque sigue llegando a la app de abajo)
            root.setOnTouchListener { _, ev ->
                safe("tocar fuera") {
                    if (ev.action == MotionEvent.ACTION_OUTSIDE) { h.removeCallbacks(hideR); hideR.run() }
                }
                false
            }
        }
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        if (outside) flags = flags or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )
        val p = prof()
        lp.gravity = Gravity.CENTER_VERTICAL or (if (Prefs.side(this, p) == 0) Gravity.START else Gravity.END)
        lp.x = dp(8)
        lp.y = ((Prefs.y(this, p) - 50) / 100f * resources.displayMetrics.heightPixels).toInt()
        try { wm.addView(root, lp); panel = root; builtFor = active } catch (_: Exception) {}
    }

    override fun onDestroy() {
        safe("cerrar servicio") { stopRepeat(); h.removeCallbacks(hideR); removePanel() }
        super.onDestroy()
    }
}
