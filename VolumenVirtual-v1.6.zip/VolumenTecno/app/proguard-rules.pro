# Deja los nombres legibles para que el diagnóstico de errores sea útil
-keepattributes SourceFile,LineNumberTable
-keepnames class com.tecno.volumen.**
-keepclassmembernames class com.tecno.volumen.** { *; }
