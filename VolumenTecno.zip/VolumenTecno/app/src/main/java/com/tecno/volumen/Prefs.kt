package com.tecno.volumen

import android.content.Context
import android.media.AudioManager

object Prefs {
    val STREAMS = intArrayOf(
        AudioManager.STREAM_MUSIC, AudioManager.STREAM_RING, AudioManager.STREAM_NOTIFICATION,
        AudioManager.STREAM_ALARM, AudioManager.STREAM_VOICE_CALL
    )
    val NAMES = arrayOf("Multimedia", "Timbre", "Notificación", "Alarma", "Llamada")
    val ICONS = arrayOf("🎵", "🔔", "💬", "⏰", "📞")
    private val DEFAULT_NAMES = arrayOf("Juegos", "Música", "Series")

    private fun sp(c: Context) = c.getSharedPreferences("volumen", Context.MODE_PRIVATE)

    fun getInt(c: Context, k: String, d: Int) = sp(c).getInt(k, d)
    fun put(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()

    fun enabled(c: Context) = sp(c).getBoolean("on", true)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("on", v).apply()

    fun active(c: Context) = getInt(c, "active", 0)
    fun style(c: Context) = getInt(c, "style", 0)
    fun timeout(c: Context, i: Int) = getInt(c, "t$i", 3)    // segundos, por perfil
    fun scale(c: Context) = getInt(c, "scale", 100)          // 70..150 (%)
    fun closeOutside(c: Context) = sp(c).getBoolean("outside", true)
    fun setCloseOutside(c: Context, v: Boolean) = sp(c).edit().putBoolean("outside", v).apply()

    fun name(c: Context, i: Int) = DEFAULT_NAMES[i]
    fun side(c: Context, i: Int) = getInt(c, "s$i", 1)      // 0 izquierda, 1 derecha
    fun y(c: Context, i: Int) = getInt(c, "y$i", 50)        // 0 arriba .. 100 abajo
    fun stream(c: Context, i: Int) = getInt(c, "st$i", 0)   // índice en STREAMS

    fun apps(c: Context, i: Int): Set<String> = sp(c).getStringSet("a$i", emptySet())!!.toSet()
    fun setApps(c: Context, i: Int, s: Set<String>) = sp(c).edit().putStringSet("a$i", s).apply()

    fun profileForApp(c: Context, pkg: String): Int {
        for (i in 0..2) if (pkg in apps(c, i)) return i
        return -1
    }
}
