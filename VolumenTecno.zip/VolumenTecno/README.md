# Volumen Virtual

Panel de volumen propio y ligero para Android (pensado para Tecno Camon 18P / HiOS). Sin anuncios, sin internet, sin dependencias.

## Qué hace
- Intercepta los botones de volumen (servicio de accesibilidad) y muestra un panel estilo Samsung o Xiaomi sobre cualquier app.
- Multimedia, timbre, notificación, alarma y llamada (en llamada cambia solo a volumen de llamada).
- 3 perfiles (Juegos, Música, Series): lado, altura del panel y volumen que controlan. Puedes asignar apps a cada perfil.

## Compilar desde GitHub (sin PC)
1. Sube todo este proyecto a un repositorio nuevo, rama `main`.
2. Pestaña **Actions** → **Build APK** → ejecuta si no corrió sola.
3. Al terminar, descarga el artefacto **VolumenTecno** (contiene el APK) e instálalo.

## Configuración en el teléfono (HiOS)
1. Abre la app → activa **Accesibilidad** → Volumen Virtual.
2. Pulsa **Ignorar optimización de batería** → Permitir.
3. Ajustes de la app → Batería: **Sin restricciones**; permitir **Inicio automático**.
4. Recientes: mantén pulsada la app y **bloquéala** para que HiOS no la cierre.

## Notas
- No necesita el permiso "mostrar sobre otras apps": el panel se dibuja como overlay de accesibilidad.
- Timbre/notificación a 0 puede pedir acceso a "No molestar" en Ajustes del sistema.
