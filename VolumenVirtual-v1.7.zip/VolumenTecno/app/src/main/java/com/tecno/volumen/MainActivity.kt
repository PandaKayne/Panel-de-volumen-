package com.tecno.volumen

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    override fun onResume() { super.onResume(); render() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, sp: Float = 15f, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sp
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(8), 0, dp(4))
    }

    private fun btn(t: String, on: () -> Unit) = Button(this).apply { text = t; setOnClickListener { on() } }

    private fun spin(opts: List<String>, sel: Int, on: (Int) -> Unit) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, opts)
        setSelection(sel, false)
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { on(pos) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun a11yOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        return s?.contains("$packageName/") == true
    }

    private fun render() {
        val me = this
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(32))
        }
        box.addView(tv("Volumen Virtual", 26f, true))
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "?" }
        box.addView(tv("Versión $ver", 12f))

        // 1. Accesibilidad
        if (a11yOn()) {
            box.addView(tv("✅ Accesibilidad activada"))
            box.addView(tv("Si Android dice que el servicio no funciona bien: desactívalo y vuelve a activarlo en Accesibilidad.", 12f))
        }
        else {
            box.addView(tv("❌ Accesibilidad desactivada (necesaria)"))
            box.addView(btn("Activar accesibilidad") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        }

        // 2. Batería
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) box.addView(tv("✅ Sin optimización de batería"))
        else {
            box.addView(tv("❌ Batería optimizada (el sistema puede cerrarla)"))
            box.addView(btn("Ignorar optimización de batería") {
                try {
                    startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
            })
        }
        // 2b. No molestar (necesario para activar el modo silencio)
        val nm = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
        if (nm.isNotificationPolicyAccessGranted) box.addView(tv("✅ Acceso a No molestar (para el silencio)"))
        else {
            box.addView(tv("❌ Sin acceso a No molestar (hace falta para activar el silencio)"))
            box.addView(btn("Dar acceso a No molestar") {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            })
        }
        box.addView(btn("Ajustes de la app (inicio automático)") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })

        // 3. Ajustes generales
        box.addView(Switch(this).apply {
            text = "Panel de volumen activado"
            isChecked = Prefs.enabled(me)
            setOnCheckedChangeListener { _, c -> Prefs.setEnabled(me, c) }
        })
        box.addView(tv("Estilo y color del panel"))
        val bars = listOf(0.8f, 0.5f, 0.3f).map { f -> VBar(me, 0x33FFFFFF, Prefs.fill(me)).apply { frac = f } }
        val prevBg = GradientDrawable().apply { setColor(Prefs.bg(me)); cornerRadius = dp(20).toFloat() }
        val prev = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            background = prevBg
            setPadding(dp(16), dp(12), dp(16), dp(12))
            bars.forEach { addView(it, LinearLayout.LayoutParams(dp(30), dp(90)).apply { setMargins(dp(6), 0, dp(6), 0) }) }
        }
        box.addView(spin(Prefs.STYLE_NAMES.toList(), Prefs.style(me)) {
            Prefs.put(me, "style", it)
            prevBg.setColor(Prefs.bg(me))
            bars.forEach { b -> b.fill = Prefs.fill(me) }
        })
        box.addView(prev, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        box.addView(Switch(this).apply {
            text = "Cerrar el panel al tocar fuera"
            isChecked = Prefs.closeOutside(me)
            setOnCheckedChangeListener { _, c -> Prefs.setCloseOutside(me, c) }
        })
        box.addView(btn("Apps sin panel (${Prefs.excluded(me).size})") {
            chooseApps("Apps donde los botones funcionan normal", Prefs.excluded(me)) { Prefs.setExcluded(me, it) }
        })
        box.addView(tv("La cámara se detecta sola: ahí los botones de volumen toman la foto.", 13f))
        val scaleLabel = tv("Escala del panel: ${Prefs.scale(me)}%")
        box.addView(scaleLabel)
        box.addView(SeekBar(this).apply {
            max = 80; progress = Prefs.scale(me) - 70   // 70% a 150%
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    scaleLabel.text = "Escala del panel: ${p + 70}%"
                    if (fromUser) Prefs.put(me, "scale", p + 70)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        // 4. Perfiles
        box.addView(tv("Perfil por defecto", 18f, true))
        box.addView(spin((0..2).map { Prefs.name(me, it) }, Prefs.active(me)) { Prefs.put(me, "active", it) })

        for (i in 0..2) {
            box.addView(tv("Perfil: ${Prefs.name(me, i)}", 18f, true).apply { setPadding(0, dp(24), 0, dp(4)) })
            box.addView(tv("Lado del panel"))
            box.addView(spin(listOf("Izquierda", "Derecha"), Prefs.side(me, i)) { Prefs.put(me, "s$i", it) })
            box.addView(tv("Altura (arriba ↔ abajo)"))
            box.addView(SeekBar(this).apply {
                max = 100; progress = Prefs.y(me, i)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) Prefs.put(me, "y$i", p) }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            })
            box.addView(tv("Se cierra tras"))
            val tOpts = listOf(2, 3, 5, 8)
            box.addView(spin(tOpts.map { "$it s" }, tOpts.indexOf(Prefs.timeout(me, i)).coerceAtLeast(0)) { Prefs.put(me, "t$i", tOpts[it]) })
            box.addView(tv("Los botones controlan"))
            box.addView(spin(Prefs.NAMES.take(4), Prefs.stream(me, i)) { Prefs.put(me, "st$i", it) })
            box.addView(btn("Apps de este perfil (${Prefs.apps(me, i).size})") { pickApps(i) })
        }
        box.addView(tv("Al abrir una app asignada a un perfil, el panel cambia solo a la posición de ese perfil.", 13f))

        box.addView(tv("Diagnóstico", 18f, true).apply { setPadding(0, dp(24), 0, dp(4)) })
        val err = Prefs.lastError(me)
        if (err == null) box.addView(tv("Sin errores registrados.", 13f))
        else {
            box.addView(TextView(this).apply { text = err; textSize = 12f; setTextIsSelectable(true) })
            box.addView(btn("Copiar error") {
                val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("error", err))
                android.widget.Toast.makeText(me, "Copiado", android.widget.Toast.LENGTH_SHORT).show()
            })
            box.addView(btn("Borrar error") { Prefs.clearError(me); render() })
        }

        setContentView(ScrollView(this).apply { addView(box) })
    }

    private fun pickApps(i: Int) =
        chooseApps("Apps: ${Prefs.name(this, i)}", Prefs.apps(this, i)) { Prefs.setApps(this, i, it) }

    private fun chooseApps(title: String, current: Set<String>, save: (Set<String>) -> Unit) {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .filter { it.second != packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
        val sel = current.toMutableSet()
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMultiChoiceItems(
                apps.map { it.first }.toTypedArray(),
                BooleanArray(apps.size) { apps[it].second in sel }
            ) { _, which, on -> if (on) sel.add(apps[which].second) else sel.remove(apps[which].second) }
            .setPositiveButton("Guardar") { _, _ -> save(sel); render() }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
